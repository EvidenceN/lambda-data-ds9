
"""
Functions for doing data analysis.

"""